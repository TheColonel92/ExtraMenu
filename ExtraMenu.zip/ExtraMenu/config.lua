Config = {}

Config.MenuKey = 168

-- Par d�faut = 244 [M]  |  Pour changer le bouton, consultez https://docs.fivem.net/game-references/controls/

Config.requirePerms = false

-- Lorsqu'il est activ� (true), un utilisateur doit avoir les permissions ace pour ouvrir le menu.

-- Si utilis�, ajoutez ceci au server.cfg : "add_ace identifier.steam:steamidhere use.ExtraMenu" allow ou "add_ace group.groupName use.ExtraMenu allow"

Config.locationOpen = false

-- Par d�faut = false | Lorsqu'il est vrai, vous devrez entrer des informations dans Config.locationMarker, car le menu ne fonctionnera que lorsque un joueur marche sur un marqueur sur la carte.

Config.commandOpen = false

-- Par d�faut = false | Lorsqu'il est vrai, vous pourrez ouvrir le menu via la commande d�finie sur la ligne suivante. | Ne fonctionne pas avec "locationOpen".

Config.command = 'extramenu'

-- Par d�faut = 'extramenu' | Cela d�finit la commande utilis�e pour ouvrir le menu des extras lorsque "Config.commandOpen = true".

Config.commandOnly = false

-- Par d�faut = false | Lorsqu'il est activ�, le menu ne peut �tre ouvert qu'avec la commande.

Config.MenuOrientation = 1

-- Gauche = 0  |  Droite = 1 [Par d�faut]

Config.MenuWidth = 80

-- Par d�faut = 80

Config.MenuTitle = 0

-- Par d�faut       = Le titre par d�faut du menu est 'Extras Menu'

-- Nom du joueur   = C'est le nom du joueur

-- Personnalis�    = C'est un titre personnalis� d�fini par vous dans Config.MenuTitleCustom

-- Par d�faut = 0 [Par d�faut]  |  Nom du joueur = 1  |  Personnalis� = 2

Config.MenuTitleCustom = 'Extras Menu'

-- Si choisi dans Config.MenuTitle

Config.EnableCredits = 'false'

-- Activ� = true  |  D�sactiv� = false

-- Nous aimerions que vous les laissiez activ�s, mais nous savons que parfois cela rend mieux de les d�sactiver. :)

Config.DamageStopper = false

-- L'activation de ceci signifie que les v�hicules ne pourront pas changer leurs extras lorsqu'ils d�passeront la limite de dommages.

-- Note : Il est recommand� de d�sactiver ceci lors de l'utilisation de "locationOpen", car vous devriez avoir les emplacements dans les ateliers de r�paration de toute fa�on.

Config.DamageLimit = 980

-- La valeur maximale de dommages qu'un v�hicule peut avoir. Tout d�passement de cette valeur emp�chera le v�hicule de changer d'extras. [Par d�faut = 980]

Config.CustomNames = {

    {vehicle = '19Charger', extra = {
        ['1'] = 'Ram Bar', ['2'] = 'Light Bar', ['3'] = 'Visor Lights', ['4'] = 'Dashboard Lights', ['5'] = 'Spot Lights'
    }},
    {vehicle = 'megane4staff', extra = {
        ['1'] = 'Deviation gauche', ['2'] = 'Deviation droit', ['3'] = 'Interdiction', ['4'] = 'Dashboard Lights', ['5'] = 'Spot Lights'
    }},
}

-- Si vous voulez que les noms des extras s'affichent comme quelque chose de personnalis� pour certains v�hicules

--[[
Format: 
    {vehicle = 'spawncode', extra = {
        ['extra_number'] = 'custom name', ['extra_number'] = 'custom name', ['extra_number'] = 'custom name'
    }},
EX:
    {vehicle = '19Charger', extra = {
        ['1'] = 'Ram Bar', ['2'] = 'Light Bar', ['3'] = 'Visor Lights', ['4'] = 'Dashboard Lights', ['5'] = 'Spot Lights'
    }},
]] 

-- Vous pouvez en ajouter plus dans la section extra

Config.enableLivery = false

-- Active (true)/d�sactive (false) le changement de livr�e

Config.CustomLiveryNames = {

    {vehicle = '19Charger', livery = {
        [0] = 'Sheriff', [1] = 'Police', [2] = 'Unmarked'
    }},
}

-- Si vous voulez que les noms des livr�es s'affichent comme quelque chose de personnalis� pour certains v�hicules (Les livr�es commencent � 0, pas � 1)

--[[
Format: 
    {vehicle = 'spawncode', livery = {
        [livery_number] = 'custom name', [livery_number] = 'custom name', [livery_number] = 'custom name'
    }},
EX:
    {vehicle = '19Charger', livery = {
        [0] = 'Sheriff', [1] = 'Police', [2] = 'Unmarked'
    }},
]] 

-- Vous pouvez en ajouter plus dans la section livery

Config.positions = {
    -- {{X du marqueur, Y du marqueur, Z du marqueur, Cap du marqueur}, {Rouge, Vert, Bleu}, "Texte pour le marqueur"} (Ne mettez pas la cl� � appuyer dans le texte, elle est ajout�e automatiquement.)
    {{1867.42, 3666.11, 32.80, 0},{36,237,157}, "Test"} -- � l'ext�rieur du poste de police
}