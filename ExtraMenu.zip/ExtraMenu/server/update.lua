local label = [[Extra Script Menu par TheColonel]]

Citizen.CreateThread(function()
	Citizen.Wait(3000)
	print(label)
end)
