fx_version 'cerulean'

games {'gta5'}

real_name 'ExtraMenu'

description 'Un menu simple pour faciliter la modification des extras du vehicule avec la possibilite de personnaliser les noms des extras dans le menu pour certains vehicules.'

author 'TheColonel'

version '3.5.0'

config_version '3.0'

url ''



client_scripts {

    '@NativeUI/NativeUI.lua',  -- Bibliotheque NativeUI

    'keys.lua',  -- Script des touches

    'client/*.lua'  -- Tous les scripts cot� client

}



server_scripts {

    'keys.lua',  -- Script des touches

    'server/*.lua'  -- Tous les scripts cot� serveur

}



shared_scripts {

    'config.lua',  -- Script de configuration

}



dependency "NativeUI"
